﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaimsDataLayer
{
    public class Member:MemberPlan
    {
        private int _memberId;
        private string _firstName;
        private string _lastName;
        private int age;
        private string gender;
        private DateTime _dob;
        private long _contactNumber;
        private long _altContactNumber;
        private string _emailId;
        private string _password;
        private string _addressLine1;
        private string _addressLine2;
        private string _city;
        private string _state;
        private string _zipCode;
        private string _active;
        private Claim claim;

        public Member()
        {
                
        }
        public Member(int _memberId, string _firstName, string _lastName, int age, string gender, DateTime _dob, long _contactNumber, long _altContactNumber, string _emailId, string _password, string _addressLine1, string _addressLine2, string _city, string _state, string _zipCode, string _active, Claim claim)
        {
            this._memberId = _memberId;
            this._firstName = _firstName;
            this._lastName = _lastName;
            this.age = age;
            this.gender = gender;
            this._dob = _dob;
            this._contactNumber = _contactNumber;
            this._altContactNumber = _altContactNumber;
            this._emailId = _emailId;
            this._password = _password;
            this._addressLine1 = _addressLine1;
            this._addressLine2 = _addressLine2;
            this._city = _city;
            this._state = _state;
            this._zipCode = _zipCode;
            this._active = _active;
            this.claim = claim;
        }

        public int MemberId
        {
            get
            {
                return _memberId;
            }

            set
            {
                _memberId = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }

        public int Age
        {
            get
            {
                return age;
            }

            set
            {
                age = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public DateTime Dob
        {
            get
            {
                return _dob;
            }

            set
            {
                _dob = value;
            }
        }

        public long ContactNumber
        {
            get
            {
                return _contactNumber;
            }

            set
            {
                _contactNumber = value;
            }
        }

        public long AltContactNumber
        {
            get
            {
                return _altContactNumber;
            }

            set
            {
                _altContactNumber = value;
            }
        }

        public string EmailId
        {
            get
            {
                return _emailId;
            }

            set
            {
                _emailId = value;
            }
        }

        public string Password
        {
            get
            {
                return _password;
            }

            set
            {
                _password = value;
            }
        }

        public string AddressLine1
        {
            get
            {
                return _addressLine1;
            }

            set
            {
                _addressLine1 = value;
            }
        }

        public string AddressLine2
        {
            get
            {
                return _addressLine2;
            }

            set
            {
                _addressLine2 = value;
            }
        }

        public string City
        {
            get
            {
                return _city;
            }

            set
            {
                _city = value;
            }
        }

        public string State
        {
            get
            {
                return _state;
            }

            set
            {
                _state = value;
            }
        }

        public string ZipCode
        {
            get
            {
                return _zipCode;
            }

            set
            {
                _zipCode = value;
            }
        }

        public string Active
        {
            get
            {
                return _active;
            }

            set
            {
                _active = value;
            }
        }

        public Claim Claim
        {
            get
            {
                return claim;
            }

            set
            {
                claim = value;
            }
        }
    }
}
