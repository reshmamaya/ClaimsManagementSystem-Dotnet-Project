﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaimsDataLayer
{
   public  class CustomClassClaim
    {
        private int _planCodeId;
        private string _planName;
        private string _planDescription;
        private DateTime _startDate;
        private DateTime _endDate;
        private float _coverageAmount;
        private string _claimStatus;

        public int PlanCodeId
        {
            get
            {
                return _planCodeId;
            }

            set
            {
                _planCodeId = value;
            }
        }

        public string PlanName
        {
            get
            {
                return _planName;
            }

            set
            {
                _planName = value;
            }
        }

        public string PlanDescription
        {
            get
            {
                return _planDescription;
            }

            set
            {
                _planDescription = value;
            }
        }

        public DateTime StartDate
        {
            get
            {
                return _startDate;
            }

            set
            {
                _startDate = value;
            }
        }

        public DateTime EndDate
        {
            get
            {
                return _endDate;
            }

            set
            {
                _endDate = value;
            }
        }

        public float CoverageAmount
        {
            get
            {
                return _coverageAmount;
            }

            set
            {
                _coverageAmount = value;
            }
        }

        public string ClaimStatus
        {
            get
            {
                return _claimStatus;
            }

            set
            {
                _claimStatus = value;
            }
        }
    }
}
