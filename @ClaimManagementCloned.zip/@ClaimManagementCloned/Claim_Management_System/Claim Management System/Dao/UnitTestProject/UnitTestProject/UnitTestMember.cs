﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClaimsDataLayer;
using ClaimsBusinessLayer;
using System.Collections.Generic;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTestMember
    {
        [TestMethod]
        public void TestApproveMember()
        {
            MemberDao memberDao = new MemberDao();
            int result = memberDao.ApproveMember(2,"Yes");
            Assert.AreEqual(1, result);

        }

        [TestMethod]
        public void TestGetMemberById()
        {
            MemberDao memberDao = new MemberDao();
            Member member = memberDao.GetMemberById(2);
            Assert.AreEqual(2, member.MemberId);

        }

        [TestMethod]
        public void TestLoginMember()
        {
            MemberDao memberDao = new MemberDao();
            int result = memberDao.LoginMember("sam@gmail.com","sam@123");
            // credentials not correct
            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void TestLoginMember1()
        {
            MemberDao memberDao = new MemberDao();
            int result = memberDao.LoginMember("reshmanair@gmail.com", "resh@123");
            // credentials correct and active
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestLoginMember2()
        {
            MemberDao memberDao = new MemberDao();
            int result = memberDao.LoginMember("joe@gmail.com", "joe@135");
            // credentials correct, not active
            Assert.AreEqual(2, result);
        }

        [TestMethod]
        public void TestLoginMember3()
        {
            MemberDao memberDao = new MemberDao();
            int result = memberDao.LoginMember("kohi@gmail.com", "kohi@135");
            // credentials correct active processing
            Assert.AreEqual(3, result);
        }

        [TestMethod]
        public void TestRegisterMember()
        {
            MemberDao memberDao = new MemberDao();
            Member member = new Member(3, "Joe", "Mathew", 21, "Female", DateTime.Parse("07/09/1997"), 9876543211, 9765432220, "joe@gmail.com", "joe@135", "45, S V Nagar", "Siruseri", "Chennai", "Tamil Nadu", "600119", "No");
            int result = memberDao.RegisterMember(member);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestGetMemberList()
        {
            MemberDao memberDao = new MemberDao();
            List<Member> memberList = memberDao.GetMemberList();
            Assert.AreEqual(5, memberList.Count);
        }
        
        [TestMethod]
        public void TestGetMemberListForAdmin()
        {
            MemberDao memberDao = new MemberDao();
            List<Member> memberList = memberDao.GetMemberListForAdmin();
            Assert.AreEqual(4, memberList.Count);
        }

        [TestMethod]
        public void TestRemoveMember()
        {
            MemberDao memberDao = new MemberDao();
            int result = memberDao.RemoveMember(7);
            Assert.AreEqual(1, result);
        }

 	[TestMethod]
        public void TestGetMemberId()
        {
            MemberDao memberDao = new MemberDao();
            int result = memberDao.GetMemberId("reshmanair@gmail.com", "resh@123");
            Assert.AreEqual(1, result);
        }
    }
}
