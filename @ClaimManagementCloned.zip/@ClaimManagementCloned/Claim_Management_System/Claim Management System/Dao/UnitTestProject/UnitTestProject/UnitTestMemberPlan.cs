﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClaimsDataLayer;
using ClaimsBusinessLayer;
using System.Collections.Generic;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTestMemberPlan
    {
        [TestMethod]
        public void TestAddMemberPlan()
        {
            MemberPlanDao memberPlanDao = new MemberPlanDao();
            MemberPlan memberPlan = new MemberPlan(1, 1, 1, DateTime.Parse("09/18/2019"), DateTime.Parse("12/18/2019"), 10000000.00f,2);
            int result = memberPlanDao.AddMemberPlan(memberPlan);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestGetMemberPlanInMember()
        {
            MemberPlanDao memberPlanDao = new MemberPlanDao();
            List<MemberPlan> memberPlanList = memberPlanDao.GetMemberPlanInMember(1);
            Assert.AreEqual(1, memberPlanList.Count);
        }

    }
}
