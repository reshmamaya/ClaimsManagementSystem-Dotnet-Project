﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClaimsDataLayer;
using ClaimsBusinessLayer;
using System.Collections.Generic;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTestPlanCode
    {
        [TestMethod]
        public void TestAddPlan()
        {
            PlanCodeDao planCodeDao = new PlanCodeDao();
            PlanCode planCode = new PlanCode(5, "Life Insurance", "Life insurance is a contract between an insurance policy holder and an insurer or assurer, where the insurer promises to pay a designated beneficiary a sum of money (the benefit) in exchange for a premium, upon the death of an insured person", 
                5000000.00f, 40000000.00f, 30000000.00f, 20000000.00f, 10000000.00f);
            int result = planCodeDao.AddPlan(planCode);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestEditPlan()
        {
            PlanCodeDao planCodeDao = new PlanCodeDao();
            PlanCode planCode = new PlanCode(2, "Health Insurance", "Health insurance is a contract between an insurance policy holder and an insurer or assurer, where the insurer promises to pay a designated beneficiary a sum of money (the benefit) in exchange for a premium, upon the accident or illness of an insured person",
                5000000.00f, 40000000.00f, 30000000.00f, 20000000.00f, 10000000.00f);
            int result = planCodeDao.EditPlan(planCode);
            Assert.AreEqual(1, result);

        }

        [TestMethod]
        public void TestRemovePlan()
        {
            PlanCodeDao planCodeDao = new PlanCodeDao();
            int result = planCodeDao.RemovePlan(2);
            Assert.AreEqual(1, result);

        }

        [TestMethod]
        public void TestViewPlan()
        {
            PlanCodeDao planCodeDao = new PlanCodeDao();
            List<PlanCode> planCodeList= planCodeDao.ViewPlan();
            Assert.AreEqual(1, planCodeList.Count);

        }
    }
}
