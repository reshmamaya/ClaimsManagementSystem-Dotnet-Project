﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClaimsDataLayer;
using ClaimsBusinessLayer;
using System.Collections.Generic;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTestClaim
    {
        [TestMethod]
        public void TestRequestClaim()
        {
            ClaimDao claimDao = new ClaimDao();
            Claim claim = new Claim(3, 4, DateTime.Parse("09/09/2019"), DateTime.Parse("10/09/2019"), DateTime.Parse("11/11/2019"),"processing",300000.00f,250000.00f);
            int result = claimDao.RequestClaim(claim);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestResubmitClaim()
        {
            ClaimDao claimDao = new ClaimDao();
            Claim claim = new Claim(3, 4, DateTime.Parse("09/09/2019"), DateTime.Parse("10/09/2019"), DateTime.Parse("11/11/2019"), "processing", 300000.00f, 250000.00f);
            int result = claimDao.RequestClaim(claim);

        }

        [TestMethod]
        public void TestApproveClaim()
        {
            ClaimDao claimDao = new ClaimDao();
            int result = claimDao.ApproveClaim(3, "Approved",250000.00f);
            Assert.AreEqual(1, result);

        }

        [TestMethod]
        public void TestViewClaimForAdmin()
        {
            ClaimDao claimDao = new ClaimDao();
            List<Claim> claimList = claimDao.ViewClaimForAdmin();
            Assert.AreEqual(1, claimList.Count);

        }

        [TestMethod]
        public void TestViewClaimForCustomer()
        {
            ClaimDao claimDao = new ClaimDao();
            List<Claim> claimList = claimDao.ViewClaimForCustomer(1);
            Assert.AreEqual(1, claimList.Count);

        }
    }
}
