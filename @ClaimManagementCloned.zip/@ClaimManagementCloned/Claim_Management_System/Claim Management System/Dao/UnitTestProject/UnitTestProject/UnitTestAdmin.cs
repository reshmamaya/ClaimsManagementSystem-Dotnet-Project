﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClaimsDataLayer;
using ClaimsBusinessLayer;
using System.Collections.Generic;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTestAdmin
    {
        [TestMethod]
        public void TestApproveAdmin()
        {
            AdminDao adminDao = new AdminDao();
            int result = adminDao.ApproveAdmin(1, "Yes");
            Assert.AreEqual(1, result);

        }

        [TestMethod]
        public void TestGetAdminById()
        {
            AdminDao adminDao = new AdminDao();
            Admin admin = adminDao.GetAdminById(1);
            Assert.AreEqual(1, admin.AdminID);

        }

        [TestMethod]
        public void TestLoginadmin()
        {
            AdminDao adminDao = new AdminDao();
            int result = adminDao.LoginAdmin("merry@gmail.com", "merry@123");
            // credentials correct and active
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestLoginadmin1()
        {
            AdminDao adminDao = new AdminDao();
            int result = adminDao.LoginAdmin("john@gmail.com", "john@246");
            // credentials correct and not active
            Assert.AreEqual(2, result);
        }

        [TestMethod]
        public void TestLoginadmin2()
        {
            AdminDao adminDao = new AdminDao();
            int result = adminDao.LoginAdmin("park@gmail.com", "park@246");
            // credentials not correct
            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void TestLoginadmin3()
        {
            AdminDao adminDao = new AdminDao();
            int result = adminDao.LoginAdmin("sam@gmail.com", "sam@246");
            // credentials correct and active processing
            Assert.AreEqual(3, result);
        }

        [TestMethod]
        public void TestRegisteradmin()
        {
            AdminDao adminDao = new AdminDao();
            Admin admin = new Admin(2, "John", "Bruce", 21, "Male", DateTime.Parse("08/03/1997"), 9876543456, 9765541230, "john@gmail.com", "john@246", "No");
            int result = adminDao.RegisterAdmin(admin);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestGetadminList()
        {
            AdminDao adminDao = new AdminDao();
            List<Admin> adminList = adminDao.GetAdminList();
            Assert.AreEqual(2, adminList.Count);
        }

        [TestMethod]
        public void TestGetAdminListForSuperUser()
        {
            AdminDao adminDao = new AdminDao();
            List<Admin> adminList = adminDao.GetAdminListForSuperUser();
            Assert.AreEqual(1, adminList.Count);
        }

        [TestMethod]
        public void TestRemoveAdmin()
        {
            AdminDao adminDao = new AdminDao();
            int result = adminDao.RemoveAdmin(2);
            Assert.AreEqual(1, result);
        }
    }
}
