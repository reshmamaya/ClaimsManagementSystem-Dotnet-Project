﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ClaimsDataLayer;

namespace ClaimsBusinessLayer
{
    public class ClaimDao : IClaimDao
    {
        public static string callConnection = ConnectionHandler.ConnectionVariable;
        public int ApproveClaim(int claimId, string claimStatus, float approvedAmount)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                int result;
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.approveClaim
                };

                command.Parameters.Add(Constants.atClaimId, SqlDbType.Int).Value = claimId;
                command.Parameters.Add(Constants.atClaimStatus, SqlDbType.VarChar).Value = claimStatus;
                command.Parameters.Add(Constants.atApprovedAmount, SqlDbType.Decimal).Value = approvedAmount;

                result = command.ExecuteNonQuery();
                return result;
            }
        }

        public int RequestClaim(Claim claim)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                int result;
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.requestClaim
                };
                
                command.Parameters.Add(Constants.atMemberPlanId, SqlDbType.Int).Value = claim.MemberPlanId1;
                command.Parameters.Add(Constants.atClaimServiceDate, SqlDbType.Date).Value = claim.ClaimServiceDate;
                command.Parameters.Add(Constants.atClaimProcessingDate, SqlDbType.Date).Value = claim.ClaimProcessingDate;
                command.Parameters.Add(Constants.atClaimSubmissionDate, SqlDbType.Date).Value = claim.ClaimSubmissionDate;
                command.Parameters.Add(Constants.atClaimStatus, SqlDbType.VarChar).Value = claim.ClaimStatus;
                command.Parameters.Add(Constants.atClaimAmount, SqlDbType.Decimal).Value = claim.ClaimAmount;
                command.Parameters.Add(Constants.atApprovedAmount, SqlDbType.Decimal).Value = claim.ApprovedAmount;

                result = command.ExecuteNonQuery();
                return result;
            }
        }

        public int ResubmitClaim(int claimId)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                int result;
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.resubmitClaim
                };

                command.Parameters.Add(Constants.atClaimId, SqlDbType.Int).Value = claimId;
                //command.Parameters.Add(Constants.atClaimServiceDate, SqlDbType.Date).Value = claim.ClaimServiceDate;
                //command.Parameters.Add(Constants.atClaimProcessingDate, SqlDbType.Date).Value = claim.ClaimProcessingDate;
                //command.Parameters.Add(Constants.atClaimSubmissionDate, SqlDbType.Date).Value = claim.ClaimSubmissionDate;
                //command.Parameters.Add(Constants.atClaimStatus, SqlDbType.VarChar).Value = claim.ClaimStatus;
                //command.Parameters.Add(Constants.atClaimAmount, SqlDbType.Decimal).Value = claim.ClaimAmount;
                //command.Parameters.Add(Constants.atApprovedAmount, SqlDbType.Decimal).Value = claim.ApprovedAmount;

                result = command.ExecuteNonQuery();
                return result;
            }
        }

        public List<Claim> ViewClaimForAdmin()
        {
            List<Claim> claimList = new List<Claim>();

            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewClaimForAdmin
                };

                SqlDataReader dataReader = command.ExecuteReader();
                
                while (dataReader.Read())
                {
                    Claim claim = new Claim();
                    claim.ClaimId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimId)));
                    claim.PlanName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.planName)));
                    claim.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberFirstName)));
                    claim.ClaimServiceDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimServiceDate)));
                    claim.ClaimProcessingDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimProcessingDate)));
                    claim.ClaimSubmissionDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimSubmissionDate)));
                    claim.ClaimAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimAmount)));
                    claimList.Add(claim);
                  
                }
                if (claimList.Count == 0)
                {
                    throw new NoClaimException();
                }
                return claimList;
            }
        }
        public List<Claim> ViewClaimForCustomer(int memberId)
        {
            List<Claim> claimList = new List<Claim>();

            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewClaimForCustomer
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;

                SqlDataReader dataReader = command.ExecuteReader();
                int count = 0;
                while (dataReader.Read())
                {
                    Claim claim = new Claim();
                    claim.ClaimId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimId)));
                    claim.MemberId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberId)));
                    claim.ClaimServiceDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimServiceDate)));
                    claim.ClaimProcessingDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimProcessingDate)));
                    claim.ClaimSubmissionDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimSubmissionDate)));
                    claim.ClaimStatus = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimStatus)));
                    claim.ClaimAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimAmount)));
                    claim.ApprovedAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.approvedAmount)));

                    claimList.Add(claim);
                    count++;
                }
                if (count == 0)
                {
                    throw new NoClaimException();
                }
                return claimList;
            }
        }


        public Claim ViewClaimById(int claimId)
        {
            List<Claim> claimList = new List<Claim>();

            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewClaimbyId
                };
                command.Parameters.Add(Constants.atClaimId, SqlDbType.Int).Value = claimId;
                SqlDataReader dataReader = command.ExecuteReader();

                Claim claim = new Claim();
                while (dataReader.Read())
                {

                    //claim.ClaimId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimId)));
                    claim.PlanName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.planName)));
                    claim.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberFirstName)));
                    claim.ClaimServiceDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimServiceDate)));
                    claim.ClaimProcessingDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimProcessingDate)));
                    claim.ClaimSubmissionDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimSubmissionDate)));
                    claim.ClaimAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimAmount)));


                }
                return claim;

            }
        }


    }
}
