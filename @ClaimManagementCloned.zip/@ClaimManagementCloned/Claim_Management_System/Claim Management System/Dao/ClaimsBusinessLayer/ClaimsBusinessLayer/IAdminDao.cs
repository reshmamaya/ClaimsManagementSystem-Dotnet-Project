﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClaimsDataLayer;

namespace ClaimsBusinessLayer
{
    interface IAdminDao
    {
        bool LoginSuperUser(string userId, string password);
        int RegisterAdmin(Admin admin);
        int LoginAdmin(string emailId, string password);
        int ApproveAdmin(int adminId, string active);
        List<Admin> GetAdminList();
        Admin GetAdminById(int adminId);
        List<Admin> GetAdminListForSuperUser();
        int RemoveAdmin(int adminId);

        int ChechMail(string emailId);
    }
}
