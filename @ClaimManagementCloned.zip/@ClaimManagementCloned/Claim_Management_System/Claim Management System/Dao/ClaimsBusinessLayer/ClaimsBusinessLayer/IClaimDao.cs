﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClaimsDataLayer;

namespace ClaimsBusinessLayer
{
    interface IClaimDao
    {
        int RequestClaim(Claim claim);
        int ResubmitClaim(int claimId);
        int ApproveClaim(int claimId, string claimStatus, float approvedAmount);
        List<Claim> ViewClaimForAdmin();
        List<Claim> ViewClaimForCustomer(int memberId);
        Claim ViewClaimById(int claimId);
    }
}
