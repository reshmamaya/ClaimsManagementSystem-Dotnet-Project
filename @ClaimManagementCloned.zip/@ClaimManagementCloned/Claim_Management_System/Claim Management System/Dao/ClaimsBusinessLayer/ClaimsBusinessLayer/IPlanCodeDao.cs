﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClaimsDataLayer;

namespace ClaimsBusinessLayer
{
    interface IPlanCodeDao
    {
        int AddPlan(PlanCode planCode);
        int RemovePlan(int planCodeId);
        List<PlanCode> ViewPlan();
        int EditPlan(PlanCode planCode);
    }
}
