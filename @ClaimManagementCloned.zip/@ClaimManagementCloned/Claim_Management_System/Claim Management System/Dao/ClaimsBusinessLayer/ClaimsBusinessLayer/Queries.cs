﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaimsBusinessLayer
{
    public class Queries
    {
        public static string registerMember = "insert into [member](firstname,lastname,age,gender,dob,contactnumber,altcontactnumber,emailid,password,addressline1,addressline2,city,state,zipcode,active) values(@firstname,@lastname,@age,@gender,@dob,@contactnumber,@altcontactnumber,@emailid,@password,@addressline1,@addressline2,@city,@state,@zipcode,@active)";
        public static string loginMember = "select emailid,password,active from [member]";
        public static string approveMember = "update [member] set active=@active where memberid=@id";
        public static string getDataMember = "select * from [member];";
        public static string getMemberById = "select * from [member] where memberid = @id;";
        public static string getMemberListForAdmin = "select * from[member] where active = 'Processing'";
        public static string deleteMember = "delete from [member] where memberid=@id";
        public static string getMemberId = "select memberid from [member] where emailid=@emailid and password=@password";

        public static string deleteAdmin = "delete from [admin] where adminid=@adminid";
        public static string registerAdmin = "insert into [admin](firstname,lastname,age,gender,dob,contactnumber,altcontactnumber,password,emailid,active) values(@firstname,@lastname,@age,@gender,@dob,@contactnumber,@altcontactnumber,@password,@emailid,@active)";
        public static string loginAdmin = "select emailid,password,active from [admin]";        
        public static string approveAdmin = "update [admin] set active=@active where adminid=@adminid";        
        public static string getAdmin = "select * from [admin];";
        public static string getAdminById = "select * from [admin] WHERE adminid = @adminid";
        public static string getAdminListForSuperUser = "select * from [admin] where active = 'Processing'";

        public static string addPlan = "insert into [plancode](planname,plandescription,coverage1,coverage2,coverage3,coverage4,coverage5) values(@planname,@plandescription,@coverage1,@coverage2,@coverage3,@coverage4,@coverage5)";
        public static string removePlan = "delete from [plancode] where plancodeid=@plancodeid";
        public static string viewPlan = "select * from plancode";
        public static string editPlan = "update [plancode] set planname=@planname,plandescription=@plandescription,coverage1=@coverage1,coverage2=@coverage2,coverage3=@coverage3,coverage4=@coverage4,coverage5=@coverage5 where plancodeid=@plancodeid";

        public static string requestClaim = "insert into [claim](memberplanid,claimservicedate,claimsubmissiondate,claimprocessingdate,claimstatus,claimamount,approvedamount) values(@memberplanid,@claimservicedate,@claimsubmissiondate,@claimprocessingdate,@claimstatus,@claimamount,@approvedamount)";
        public static string resubmitClaim = "update CLAIM set CLAIMSTATUS = 'Processing' where CLAIMID=@claimId";
        public static string approveClaim = "update [claim] set claimstatus=@claimstatus, approvedamount=@approvedamount where claimid = @claimid";
       // public static string viewClaimForAdmin = "select * from [claim] where claimstatus='Processing'";
        public static string viewClaimForCustomer = "select * from [claim] where memberplanid=@memberplanid";
        public static string viewClaimbyId = "select distinct c.claimid,m.firstname,p.planname,c.claimservicedate,c.claimsubmissiondate,c.claimprocessingdate,c.claimamount from member m join memberplan mp on m.memberid=mp.memberid join plancode p on mp.plancodeid=p.plancodeid join claim c on c.memberplanid=mp.memberplanid where c.claimid = @claimid";
        public static string viewClaimForAdmin = "select distinct c.claimid,m.firstname,p.planname,c.claimservicedate,c.claimsubmissiondate,c.claimprocessingdate,c.claimamount from member m join memberplan mp on m.memberid=mp.memberid join plancode p on mp.plancodeid=p.plancodeid join claim c on c.memberplanid=mp.memberplanid where c.claimstatus='Processing'";

        public static string addMemberPlan = "insert into [memberplan](memberid,plancodeid,startdate,enddate,coverageamount,coveragenumber) values(@id,@plancodeid,@startdate,@enddate,@coverageamount,@coveragenumber)";
        public static string getMemberPlan = "select * from [memberplan]";
        public static string GetMemberPlanForIdWhereNoClaim = "select m.COVERAGENUMBER,c.CLAIMID,c.APPROVEDAMOUNT,m.MEMBERID,p.PLANCODEID,p.PLANNAME,p.PLANDESCRIPTION,m.COVERAGEAMOUNT,m.STARTDATE,m.ENDDATE,c.CLAIMSTATUS from[memberplan] m join PLANCODE p on m.PLANCODEID = p.PLANCODEID left join claim c on m.MEMBERPLANID = c.MEMBERPLANID  where memberid=@id";
        public static string GetMemberPlanId = "SELECT MEMBERPLANID FROM MEMBERPLAN where MEMBERID = @id and PLANCODEID = @plancodeid";

        public static string claimStatus = "select p.planname, p.plandescription, c.claimstatus from plancode p join memberplan mp on p.plancodeid= mp.plancodeid join member m on mp.memberid= m.memberid join claim c on m.memberid= c.memberid where m.MEMBERID= @id";
        public static string getMemberPlanForId = "select * from [memberplan] where memberid=@id";
    }
}
