﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClaimsDataLayer;

namespace ClaimsBusinessLayer
{
    interface IMemberDao
    {
        int RegisterMember(Member member);
        int  LoginMember(string emailId, string password);
        int ApproveMember(int memberId, string active);
        List<Member> GetMemberList();
        Member GetMemberById(int memberId);
        List<Member> GetMemberListForAdmin();
        int RemoveMember(int memberId);
        int GetMemberId(string emailId, string password);
        int ChechMail(string emailId);
        List<Claim> ClaimStatus(int memberId);
        List<Claim> ClaimStatusRejected(int memberId);
    }
}
