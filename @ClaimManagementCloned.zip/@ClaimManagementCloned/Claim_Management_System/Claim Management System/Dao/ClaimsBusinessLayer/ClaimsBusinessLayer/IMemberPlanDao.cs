﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClaimsDataLayer;

namespace ClaimsBusinessLayer
{
    interface IMemberPlanDao
    {
        int AddMemberPlan(MemberPlan memberPlan);
        List<MemberPlan> GetMemberPlan();
         List<MemberPlan> GetMemberPlanForId(int memberId);
        List<MemberPlan> GetMemberPlanForIdWhereNoClaim(int memberId);
        int GetMemberPlanId(int memberId, int PlanId);


    }
}
