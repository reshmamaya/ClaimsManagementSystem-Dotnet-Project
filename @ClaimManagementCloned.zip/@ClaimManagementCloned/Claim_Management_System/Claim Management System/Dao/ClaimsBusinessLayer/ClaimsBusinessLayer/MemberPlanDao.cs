﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ClaimsDataLayer;

namespace ClaimsBusinessLayer
{
    public class MemberPlanDao : IMemberPlanDao
    {
        public static string callConnection = ConnectionHandler.ConnectionVariable;
        public int AddMemberPlan(MemberPlan memberPlan)
        {
            
            int result;
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.addMemberPlan
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberPlan.MemberId;
                command.Parameters.Add(Constants.atPlanCodeId, SqlDbType.Int).Value = memberPlan.PlanCodeId;
                command.Parameters.Add(Constants.atStartDate, SqlDbType.Date).SqlValue = memberPlan.StartDate;
                command.Parameters.Add(Constants.atEndDate, SqlDbType.Date).SqlValue = memberPlan.EndDate;
                command.Parameters.Add(Constants.atCoverageAmount, SqlDbType.Decimal).Value = memberPlan.CoverageAmount;
                command.Parameters.Add(Constants.atCoverageNumber, SqlDbType.Int).Value = memberPlan.CoverageNumber;

                result = command.ExecuteNonQuery();

                return result;
            }
        }
        public List<MemberPlan> GetMemberPlan()
        {
            List<MemberPlan> memberPlanList = new List<MemberPlan>();

            int count = 0;
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getMemberPlan
                };

              

                SqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    MemberPlan memberPlan = new MemberPlan();
                    memberPlan.MemberPlanId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPlanId)));
                    memberPlan.MemberId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberId)));
                    memberPlan.PlanCodeId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.planCodeId)));
                    memberPlan.StartDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.startDate)));
                    memberPlan.EndDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.endDate)));
                    memberPlan.CoverageAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.coverageAmount)));
                    memberPlan.CoverageNumber = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.coverageNumber)));

                    memberPlanList.Add(memberPlan);
                    count++;
                }
                if (count == 0)
                {
                    throw new NoMemberPlanException();
                }
                return memberPlanList;
            }
        }

        public int GetMemberPlanId(int memberId,int PlanId)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.GetMemberPlanId
                };
                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;
                command.Parameters.Add(Constants.atPlanCodeId, SqlDbType.Int).Value = PlanId;

                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                
                       return Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("MEMBERPLANID")));
                }
                return 0;
            }

        }
        public List<MemberPlan> GetMemberPlanForIdWhereNoClaim(int memberId)
        {
            List<MemberPlan> memberPlanList = new List<MemberPlan>();

           
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.GetMemberPlanForIdWhereNoClaim
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId ;

                SqlDataReader dataReader = command.ExecuteReader();
               

                while (dataReader.Read())
                {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("CLAIMSTATUS"))) == "")
                    {
                        MemberPlan memberPlan = new MemberPlan();
                        memberPlan.CoverageNumber = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("COVERAGENUMBER")));
                        memberPlan.PlanCodeId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("PLANCODEID")));
                        memberPlan.PlanName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("PLANNAME")));
                        memberPlan.PlanDescription = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("PLANDESCRIPTION")));
                        memberPlan.CoverageAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal("COVERAGEAMOUNT")));
                        memberPlan.StartDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.startDate)));
                        memberPlan.EndDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.endDate)));

                        memberPlanList.Add(memberPlan);
                    }
                    
                }
                if (memberPlanList.Count == 0)
                {
                    throw new NoMemberPlanException();
                }
                return memberPlanList;
            }
        }

        public List<MemberPlan> GetMemberPlanForId(int memberId)
        {
            List<MemberPlan> memberPlanList = new List<MemberPlan>();


            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getMemberPlanForId
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;

                SqlDataReader dataReader = command.ExecuteReader();
               
               

                while (dataReader.Read())
                {
                    MemberPlan memberPlan = new MemberPlan();
                    memberPlan.MemberPlanId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPlanId)));
                    memberPlan.MemberId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberId)));
                    memberPlan.PlanCodeId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.planCodeId)));
                    memberPlan.StartDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.startDate)));
                    memberPlan.EndDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.endDate)));
                    memberPlan.CoverageAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.coverageAmount)));
                    memberPlan.CoverageNumber = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.coverageNumber)));

                    memberPlanList.Add(memberPlan);

                }
                if (memberPlanList.Count == 0)
                {
                    throw new NoMemberPlanException();
                }
                return memberPlanList;
            }
        }
    }
}
