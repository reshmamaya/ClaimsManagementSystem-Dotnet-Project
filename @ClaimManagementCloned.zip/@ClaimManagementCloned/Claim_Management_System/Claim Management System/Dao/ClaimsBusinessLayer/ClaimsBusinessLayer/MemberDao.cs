﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClaimsDataLayer;
using System.Data.SqlClient;
using System.Data;

namespace ClaimsBusinessLayer
{
    public class MemberDao : IMemberDao
    {
        public static string callConnection = ConnectionHandler.ConnectionVariable;
        public int RegisterMember(Member member)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                int result;
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.registerMember
                };

                command.Parameters.Add(Constants.atMemberFirstName, SqlDbType.VarChar).Value = member.FirstName;
                command.Parameters.Add(Constants.atMemberLastName, SqlDbType.VarChar).Value = member.LastName;
                command.Parameters.Add(Constants.atMemberAge, SqlDbType.Int).Value = member.Age;
                command.Parameters.Add(Constants.atMemberGender, SqlDbType.VarChar).Value = member.Gender;
                command.Parameters.Add(Constants.atMemberDob, SqlDbType.Date).Value = member.Dob;
                command.Parameters.Add(Constants.atMemberContactNumber, SqlDbType.BigInt).Value = member.ContactNumber;
                command.Parameters.Add(Constants.atMemberAltcontactNumber, SqlDbType.BigInt).Value = member.AltContactNumber;
                command.Parameters.Add(Constants.atMemberEmailId, SqlDbType.VarChar).Value = member.EmailId;
                command.Parameters.Add(Constants.atMemberPassword, SqlDbType.VarChar).Value = member.Password;
                command.Parameters.Add(Constants.atMemberAddressLine1, SqlDbType.VarChar).Value = member.AddressLine1;
                command.Parameters.Add(Constants.atMemberAddressLine2, SqlDbType.VarChar).Value = member.AddressLine2;
                command.Parameters.Add(Constants.atMemberCity, SqlDbType.VarChar).Value = member.City;
                command.Parameters.Add(Constants.atMemberState, SqlDbType.VarChar).Value = member.State;
                command.Parameters.Add(Constants.atMemberZipCode, SqlDbType.VarChar).Value = member.ZipCode;
                command.Parameters.Add(Constants.atMemberActive, SqlDbType.VarChar).Value = member.Active;

                result = command.ExecuteNonQuery();
                return result;
            }
        }

        public int LoginMember(string emailId, string password)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                int result = 0;
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.loginMember
                };

                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    if (
                        Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberEmailId))) == emailId &&
                        Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPassword))) == password
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase)
                      )
                    {
                        result = 1;//login success with active
                        break;
                    }
                    else if (
                        Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberEmailId))) == emailId &&
                        Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPassword))) == password
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive))).Equals(Constants.valueNo, StringComparison.InvariantCultureIgnoreCase)
                      )
                    {
                        result = 2;//login success with in active 
                        break;
                    }
                    else if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberEmailId))) == emailId &&
                        Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPassword))) == password
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive))).Equals(Constants.processing, StringComparison.InvariantCultureIgnoreCase))
                    {

                        result = 3;//credentails correct;active=processing
                        break;
                    }
                    else
                    {
                        result = 0;// login unsuccess
                    }

                }
                return result;
            }
        }

        public int ApproveMember(int memberId, string active)
        {
            int result;
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.approveMember
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;
                command.Parameters.Add(Constants.atMemberActive, SqlDbType.VarChar).Value = active;

                result = command.ExecuteNonQuery();
                return result;
            }
        }

        public List<Member> GetMemberList()
        {
            List<Member> memberList = new List<Member>();

            int count = 0;
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getDataMember
                };

                SqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    Member member = new Member();
                    member.MemberId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberId)));
                    member.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberFirstName)));
                    member.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberLastName)));
                    member.Age = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAge)));
                    member.Gender = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberGender)));
                    member.Dob = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberDob)));
                    member.ContactNumber = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberContactNumber)));
                    member.AltContactNumber = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAltContactNumber)));
                    member.EmailId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberEmailId)));
                    member.Password = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPassword)));
                    member.AddressLine1 = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAddressLine1)));
                    member.AddressLine2 = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAddressLine2)));
                    member.City = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberCity)));
                    member.State = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberState)));
                    member.ZipCode = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberZipCode)));
                    member.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive)));
                    memberList.Add(member);
                    count++;
                }
                if (count == 0)
                {
                    throw new NoMemberException();
                }
                return memberList;
            }
        }
        
        public Member GetMemberById(int memberId)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getMemberById
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;

                SqlDataReader dataReader = command.ExecuteReader();
                Member member = new Member();
               
               
                while (dataReader.Read())
                {
                    member.MemberId= Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberId)));
                    member.FirstName= Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberFirstName)));
                    member.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberLastName)));
                    member.Age = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAge)));
                    member.Gender = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberGender)));
                    member.Dob = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberDob)));
                    member.ContactNumber = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberContactNumber)));
                    member.AltContactNumber = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAltContactNumber)));
                    member.EmailId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberEmailId)));
                    member.Password = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPassword)));
                    member.AddressLine1 = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAddressLine1)));
                    member.AddressLine2 = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAddressLine2)));
                    member.City = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberCity)));
                    member.State = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberState)));
                    member.ZipCode = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberZipCode)));
                    member.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive)));
                    
                }
                return member;
            }
        }

        public List<Member> GetMemberListForAdmin()
        {
            List<Member> memberList = new List<Member>();

            int count = 0;
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getMemberListForAdmin
                };

                SqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    Member member = new Member();
                    member.MemberId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberId)));
                    member.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberFirstName)));
                    member.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberLastName)));
                    member.Age = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAge)));
                    member.Gender = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberGender)));
                    member.Dob = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberDob)));
                    member.ContactNumber = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberContactNumber)));
                    member.AltContactNumber = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAltContactNumber)));
                    member.EmailId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberEmailId)));
                    member.Password = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberPassword)));
                    member.AddressLine1 = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAddressLine1)));
                    member.AddressLine2 = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberAddressLine2)));
                    member.City = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberCity)));
                    member.State = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberState)));
                    member.ZipCode = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberZipCode)));
                    member.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive)));
                    memberList.Add(member);
                    count++;
                }
                if (count == 0)
                {
                    throw new NoMemberException();
                }
                return memberList;
            }
        }

        public int RemoveMember(int memberId)

        {
            int result;
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.deleteMember
                };
                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;
                result = command.ExecuteNonQuery();
                return result;

            }

        }

        public int GetMemberId(string emailId, string password)

        {

            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getMemberId
                };
                command.Parameters.Add(Constants.atMemberEmailId, SqlDbType.VarChar).Value = emailId;
                command.Parameters.Add(Constants.atMemberPassword, SqlDbType.VarChar).Value = password;

                SqlDataReader dataReader = command.ExecuteReader();
                Member member = new Member();
                while (dataReader.Read())
                {

                    member.MemberId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberId)));
                }

                return member.MemberId;
            }

        }


        public int ChechMail(string emailId)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                int result = 0;
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.loginMember
                };

                SqlDataReader dataReader = command.ExecuteReader();
               
                while (dataReader.Read())
                {
                    if (
                        Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberEmailId))) == emailId &&
                        (
                        Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase)
                        || Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.memberActive))).Equals(Constants.processing, StringComparison.InvariantCultureIgnoreCase)
                        )
                        )
                    {
                        result++;//mail present
                       
                    }
                   
                   

                }
                if(result > 0)
                {
                    return 1;//unsuccessfull
                   
                }
                else
                {
                    return 0;

                }
                
            }
        }

        public List<Claim> ClaimStatus(int memberId)
        {
            List<Claim> memberPlanList = new List<Claim>();


            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.GetMemberPlanForIdWhereNoClaim
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;

                SqlDataReader dataReader = command.ExecuteReader();


                while (dataReader.Read())
                {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimStatus))).Equals(Constants.processing,StringComparison.InvariantCultureIgnoreCase) || Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimStatus))).Equals(Constants.approved, StringComparison.InvariantCultureIgnoreCase))
                    {
                        Claim claim = new Claim();
                        claim.PlanName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.planName)));
                        claim.PlanDescription = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.planDescription)));
                        claim.ApprovedAmount = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.approvedAmount)));
                        claim.ClaimStatus = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.claimStatus)));
                        Claim c = new Claim();
                       
                        memberPlanList.Add(claim);
                    }
                }
                if (memberPlanList.Count == 0)
                {
                    throw new NoClaimException();
                }
                else
                {
                    return memberPlanList;
                }
            }

        }

        public List<Claim> ClaimStatusRejected(int memberId)
        {
            List<Claim> memberPlanList = new List<Claim>();


            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.GetMemberPlanForIdWhereNoClaim
                };

                command.Parameters.Add(Constants.atMemberId, SqlDbType.Int).Value = memberId;

                SqlDataReader dataReader = command.ExecuteReader();


                while (dataReader.Read())
                {
                    if (!(Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("CLAIMSTATUS"))).Equals("processing", StringComparison.InvariantCultureIgnoreCase)) && !(Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("CLAIMSTATUS"))).Equals("Approved", StringComparison.InvariantCultureIgnoreCase)) && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("CLAIMSTATUS"))) != "" )
                    {
                        Claim claim = new Claim();
                        claim.ClaimId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("CLAIMID")));
                        claim.PlanName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("planname")));
                        claim.PlanDescription = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("plandescription")));
                        claim.ClaimStatus = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("claimstatus")));
                        Claim c = new Claim();

                        memberPlanList.Add(claim);
                    }
                }
                if (memberPlanList.Count == 0)
                {
                    throw new NoClaimException();
                }
                else
                {
                    return memberPlanList;
                }
            }

        }
    }
}
