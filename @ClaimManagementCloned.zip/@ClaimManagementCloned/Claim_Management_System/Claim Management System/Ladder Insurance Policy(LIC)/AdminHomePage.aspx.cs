﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"] != null)
        {
            if (Session["type"].ToString() != "Admin")
            {
                Response.Redirect("AdminLogin.aspx");
            }
            
        }
        //displayCustomerList();
        //EditPlanShowData();
        if (!IsPostBack)
        {
            panelGridViewOfClaim.Visible = false;
            panelGridViewOfMembers.Visible = false;
            panelEditPlan.Visible = false;
            PanelNoMember.Visible = false;
            PanelAddPlan.Visible = false;  
            //panelNoClaim.Visible = false;
        }
    }

    public void displayCustomerList()
    {
        try
        {

            MemberDao member = new MemberDao();
            List<Member> memberList = member.GetMemberListForAdmin();
            GridViewApproveCustomer.DataSource = memberList;
            GridViewApproveCustomer.DataBind();


        }
        catch (Exception ex)
        {
            panelGridViewOfMembers.Visible = false;
            PanelNoMember.Visible = true;
        }


    }

    protected void ApproveMember(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ApproveMember")
        {
            MemberDao member = new MemberDao();
            int rowindex = int.Parse(e.CommandArgument.ToString());
            int memberId = int.Parse(GridViewApproveCustomer.Rows[rowindex].Cells[0].Text);
            member.ApproveMember(memberId, "Yes");
            Response.Write("<script>alert('" + "Member Approved" + "')</script>");

        }
        if (e.CommandName == "RejectMember")
        {
            MemberDao member = new MemberDao();
            int rowindex = int.Parse(e.CommandArgument.ToString());
            int memberId = int.Parse(GridViewApproveCustomer.Rows[rowindex].Cells[0].Text);
            member.ApproveMember(memberId, "No");
            Response.Write("<script>alert('" + "Member Rejected" + "')</script>");
        }

        displayCustomerList();


    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        panelGridViewOfClaim.Visible = false;
        panelGridViewOfMembers.Visible = true;
        panelEditPlan.Visible = false;
        PanelNoMember.Visible = false;
        PanelAddPlan.Visible = false;
        panelNoClaim.Visible = false;
        displayCustomerList();
    }

    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@<<<<<<EditPlan>>>>>>@@@@@@@@@@@@@@@@@@@@@
    protected void EditPlanShowData()
    {
        try
        {
            PlanCodeDao pDao = new PlanCodeDao();
            List<PlanCode> dt = pDao.ViewPlan();
            gridPlan.DataSource = dt;
            gridPlan.DataBind();

        }
        catch (NoPlanException ex)
        {
            Response.Write("<script>alert('" + "no policy to edit or delete" + "')</script>");
        }
       
    }

    protected void GridView1_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
    {


        try
        {
            GridViewRow row = (GridViewRow)gridPlan.Rows[e.RowIndex];
            Label lblID = (Label)row.FindControl("lblID");
            //TextBox txtname=(TextBox)gr.cell[].control[]; 
            //int planId = int.Parse(row.Cells[0].Text);
            TextBox textPlanID = (TextBox)row.Cells[0].Controls[0];
            TextBox textPlanName = (TextBox)row.Cells[1].Controls[0];
            TextBox textPlanDesc = (TextBox)row.Cells[2].Controls[0];
            TextBox textCoverage1 = (TextBox)row.Cells[3].Controls[0];
            TextBox textCoverage2 = (TextBox)row.Cells[4].Controls[0];
            TextBox textCoverage3 = (TextBox)row.Cells[5].Controls[0];
            TextBox textCoverage4 = (TextBox)row.Cells[6].Controls[0];
            TextBox textCoverage5 = (TextBox)row.Cells[7].Controls[0];
            //TextBox textadd = (TextBox)row.FindControl("txtadd");  
            //TextBox textc = (TextBox)row.FindControl("txtc");
            PlanCode plan = new PlanCode();
            plan.PlanCodeId = int.Parse(textPlanID.Text);
            plan.PlanName = textPlanName.Text;
            plan.PlanDescription = textPlanDesc.Text;
            plan.Coverage1 = int.Parse(textCoverage1.Text);
            plan.Coverage2 = int.Parse(textCoverage2.Text);
            plan.Coverage3 = int.Parse(textCoverage3.Text);
            plan.Coverage4 = int.Parse(textCoverage4.Text);
            plan.Coverage5 = int.Parse(textCoverage5.Text);
            PlanCodeDao planDao = new PlanCodeDao();
            int plane = planDao.EditPlan(plan);
            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview

            gridPlan.EditIndex = -1;
            //Call ShowData method for displaying updated data  
            EditPlanShowData();

        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + "please enter valid coverage amount " + "')</script>");

        }

    }
    protected void GridView1_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
    {
        //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
        gridPlan.EditIndex = -1;
        EditPlanShowData();
    }

    protected void gridPlan_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int planId = int.Parse(gridPlan.Rows[e.RowIndex].Cells[0].Text);
            PlanCodeDao planDao = new PlanCodeDao();
            planDao.RemovePlan(planId);
            Response.Write("<script>alert('" + "Policy removed succesfully" + "')</script>");

            EditPlanShowData();

        }
        catch (Exception ex)
        {

            Response.Write("<script>alert('" + "This policy is currently consumed by customers. Please try again once it expires " + "')</script>");
        }
    }

    protected void gridPlan_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        EditPlanShowData();
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        panelGridViewOfClaim.Visible = false;
        panelGridViewOfMembers.Visible = false;
        panelEditPlan.Visible = true;
        PanelNoMember.Visible = false;
        PanelAddPlan.Visible = false;
        panelNoClaim.Visible = false;

        EditPlanShowData();
    }







    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {

       
            gridPlan.EditIndex = e.NewEditIndex;

            EditPlanShowData();
       



    }
    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@<<<<<<EditPlan>>>>>>@@@@@@@@@@@@@@@@@@@@@

    protected void Button2_Click(object sender, EventArgs e)
    {
        PlanCode plan = new PlanCode();
       // plan.PlanCodeId = int.Parse(txtPlanCode.Text);
        plan.PlanName = txtPlanName.Text;
        plan.PlanDescription = txtPlainDescription.Text;
        plan.Coverage1 = int.Parse(txtCoverage1.Text);
        plan.Coverage2 = int.Parse(txtCoverage2.Text);
        plan.Coverage3 = int.Parse(txtCoverage3.Text);
        plan.Coverage4 = int.Parse(txtCoverage4.Text);
        plan.Coverage5 = int.Parse(txtCoverage5.Text);
        PlanCodeDao planDao = new PlanCodeDao();
        planDao.AddPlan(plan);
        Response.Write("<script>alert('" + "Policy added succesfully" + "');window.location.href='AdminHomePage.aspx'</script>");

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        panelGridViewOfClaim.Visible = false;
        panelGridViewOfMembers.Visible = false;
        panelEditPlan.Visible = false;
        PanelNoMember.Visible = false;
        panelNoClaim.Visible = false;
        PanelAddPlan.Visible = true;
    }

    protected void Button2_Click1(object sender, EventArgs e)
    {
        panelGridViewOfClaim.Visible = true;
        panelGridViewOfMembers.Visible = false;
        panelEditPlan.Visible = false;
        PanelNoMember.Visible = false;
        PanelAddPlan.Visible = false;
        panelNoClaim.Visible = false;
        DisplayDataClaimApprove();
    }



    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@<<<<<<ApproveClaim>>>>>>@@@@@@@@@@@@@@@@@@@@@

    protected void ApproveClaim(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "ApproveClaim")
        {

            int rowindex = int.Parse(e.CommandArgument.ToString());
            int claimId = int.Parse(gridViewApproveClaims.Rows[rowindex].Cells[0].Text);
            Session["Message"] = "approve";
            Response.Redirect("ClaimApprove.aspx?ClaimId=" + claimId.ToString());

        }
        if (e.CommandName == "RejectClaim")
        {
            int rowindex = int.Parse(e.CommandArgument.ToString());
            int claimId = int.Parse(gridViewApproveClaims.Rows[rowindex].Cells[0].Text);
            Session["Message"] = "reject";
            Response.Redirect("ClaimApprove.aspx?ClaimId=" + claimId.ToString());
        }


    }
    protected void DisplayDataClaimApprove()
    {
        try
        {
            ClaimDao claim = new ClaimDao();
            List<Claim> claimList = claim.ViewClaimForAdmin();
            gridViewApproveClaims.DataSource = claimList;
            gridViewApproveClaims.DataBind();
        }
        catch (NoClaimException ex)
        {
            gridViewApproveClaims.Visible = false;
            panelNoClaim.Visible =true;
        }



    }
    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@<<<<<<ApproveClaim>>>>>>@@@@@@@@@@@@@@@@@@@@@





    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtPlanName.Text = null;
        txtPlainDescription.Text = null;
        txtCoverage1.Text = null;
        txtCoverage2.Text = null;
        txtCoverage3.Text = null;
        txtCoverage4.Text = null;
        txtCoverage5.Text = null;

    }
}



