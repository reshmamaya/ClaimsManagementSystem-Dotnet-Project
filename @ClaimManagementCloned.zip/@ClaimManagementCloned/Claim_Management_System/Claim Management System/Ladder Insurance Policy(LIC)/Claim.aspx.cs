﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class _Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["type"] != null || Session["memberId"] != null)
        {
            
            if (Session["type"].ToString() != "User")
            {
                Response.Write("<script>alert('Please login as user');window.location.href='Login.aspx'</script>");
            }
            
        }
        
            lblClaimPolicyName.Text = Request.QueryString["policyName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + "Wrong navigation of page!" + "');window.location.href='CustomerHomePage.aspx';</script>");
        }

    }


   

    protected void btnRequestClaim_Click1(object sender, EventArgs e)
    {
        try
        {

           
            // int rowindex = int.Parse(e.CommandArgument.ToString());
            //  int memberId = int.Parse(gridPolicy.Rows[rowindex].Cells[1].Text);
            //claim.MemberId = int.Parse(Session["memberId"].ToString());
            MemberPlanDao memberPlanDao = new MemberPlanDao();
            Claim claim = new Claim();
            claim.MemberPlanId1 = memberPlanDao.GetMemberPlanId(int.Parse(Session["memberId"].ToString()), int.Parse(Request.QueryString["PolicyId"].ToString()));
            claim.ClaimServiceDate = DateTime.ParseExact(Request.QueryString["ServiceDate"].ToString(),"dd/MM/yyyy",null);
            claim.ClaimSubmissionDate = DateTime.Now;
            claim.ClaimProcessingDate = DateTime.Now.AddDays(10);
            claim.ClaimStatus = "Processing";
            int claimNo = int.Parse(Request.QueryString["ClaimNo"].ToString());
            float claimAmount = float.Parse(Request.QueryString["ClaimAmount"].ToString());
            switch (claimNo)
            {
                case 1: claim.ClaimAmount = claimAmount * 3 + (int)((claimAmount * 3) * .1); break;
                case 2: claim.ClaimAmount = claimAmount * 6 + (int)((claimAmount * 6) * .15); break;
                case 3: claim.ClaimAmount = claimAmount * 9 + (int)((claimAmount * 9) * .20); break;
                case 4: claim.ClaimAmount = claimAmount * 12 + (int)((claimAmount * 12) * .25); break;
                case 5: claim.ClaimAmount = claimAmount * 15 + (int)((claimAmount * 15) * .3); break;
                default:
                    break;
            }


            ClaimDao claimDao = new ClaimDao();
            claimDao.RequestClaim(claim);
            Response.Write("<script>alert('" + "Claiming initiated" + "');window.location.href='CustomerHomePage.aspx';</script>");

        }
        catch(Exception ex)
        {
            Response.Write("<script>alert('" + "something goes wrong try again !" + "');window.location.href='CustomerHomePage.aspx';</script>");
        }
    }

    
    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        Response.Redirect("CustomerHomePage.aspx");
    }
}
