﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsDataLayer;
using ClaimsBusinessLayer;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //DateTime d;
        //if (DateTime.TryParse(txtDob.Text, out d) == true && DateTime.Parse(txtDob.Text) <= DateTime.Now)
        //{
        //    TimeSpan span = DateTime.Now - d;
        //    int age = (DateTime.MinValue + span).Year;
        //    txtAge.Text = age.ToString();
        //}
        //if (IsPostBack)
        //{
        //    DateTime dt;
        //    if (DateTime.TryParse(txtDob.Text, out dt) == true && DateTime.Parse(txtDob.Text) <= DateTime.Now)
        //    {
        //        lblDateNotification.Text = "";
        //    }
        //    else
        //    {
        //        lblDateNotification.Text = "Enter Correct Date Format ";


        //    }
        lblDateNotification.Text = "";

    }
    


    protected void rdMale_CheckedChanged(object sender, EventArgs e)
    {
        if (rdMale.Checked == true)
        {
            rdFemale.Checked = false;
        }
    }

    protected void rdFemale_CheckedChanged(object sender, EventArgs e)
    {
        if (rdFemale.Checked == true)
        {
            rdMale.Checked = false;
        }
    }

    protected void btnAdminSignup_Click(object sender, EventArgs e)
    {
        DateTime d;
        if (DateTime.TryParse(txtDob.Text, out d) == true && DateTime.Parse(txtDob.Text) <= DateTime.Now)
        {
            TimeSpan span = DateTime.Now - d;
            int age = (DateTime.MinValue + span).Year;
           // txtAge.Text = age.ToString();


            AdminDao adminDao1 = new AdminDao();
            if (adminDao1.ChechMail(txtEmail.Text) != 1)
            {



                if (rdMale.Checked == false && rdFemale.Checked == false)
                {
                    Gender.Text = "*gender is mandatory";
                }
                Admin admin = new Admin();
                admin.FirstName = txtFirstName.Text;
                admin.LastName = txtLastName.Text;

                admin.Age = age ;
                admin.Dob = DateTime.Parse(txtDob.Text);
                if (rdMale.Checked == true)
                {
                    admin.Gender = "Male";
                }
                else if (rdFemale.Checked == true)
                {
                    admin.Gender = "Female";
                }
                admin.ContactNumber = Int64.Parse(txtContactNumber.Text);
                long altContactno;
                if (long.TryParse(txtAltContactNumber.Text, out altContactno))
                {
                    admin.AltContactNumber = altContactno;
                }
                else
                {

                    admin.AltContactNumber = 0;
                }
                admin.EmailId = txtEmail.Text;
                admin.Password = txtPassword.Text;
                admin.Active = "Processing";
                AdminDao adminDao = new AdminDao();

                int num = adminDao.RegisterAdmin(admin);
                if (num == 1)
                {
                    Response.Write("<script>alert('Registered Sucessfully');window.location.href='AdminLogin.aspx'</script>");
                    // Response.Redirect("");
                }
                else
                {
                    Response.Write("<script>alert('Not Registered')</script>");
                    Response.Redirect("AdminRegistration.aspx");
                }

            }

            else
            {

                alert_box.Attributes["class"] = "alert";

                lblalert.Text = "This mail id is already in use:" + txtEmail.Text;


            }


        }
        else
        {
            lblDateNotification.Text = "Enter Correct Date Format ";
        }



    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminRegistration.aspx");

    }
}


