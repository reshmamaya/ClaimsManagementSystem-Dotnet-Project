﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["type"] != null)
        {
            
            
            if (Session["type"].ToString() != "User")
            {
                Response.Redirect("Login.aspx");
            }
        }
        if (!IsPostBack)
        {
            PanelClaimMyPolicy.Visible = false;
            panelViewPolicy.Visible = false;
            panleNotification.Visible = false;
            panelNoNotification.Visible = false;
            paneNoPolicy.Visible = false;
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        PanelClaimMyPolicy.Visible = false;
        panelViewPolicy.Visible = false;
        panleNotification.Visible = true;
        paneNoPolicy.Visible = false;
        DisplayClaimStatus();
        DisplayReSubmitClaims();
    }

    protected void DisplayClaimStatus()
    {
        try
        {
            MemberDao member = new MemberDao();
            List<Claim> claimStatus = member.ClaimStatus(int.Parse(Session["memberId"].ToString()));
            gridClaimStatus.DataSource = claimStatus;
            gridClaimStatus.DataBind();
        }
        catch(Exception e)
        {
            lblApproveOrProcessing.Visible = true;
        }
    }
    //######################################################,,,,JoinPolicy...################################################
    protected void Button2_Click1(object sender, EventArgs e)
    {
        PanelClaimMyPolicy.Visible = false;
        panelViewPolicy.Visible = true;
        panleNotification.Visible = false;
        panelNoNotification.Visible = false;
        paneNoPolicy.Visible = false;

        lblmemberId.Text = Session["memberId"].ToString();
        
            displayPlan();
        
    }

    public void displayPlan()
    {

        try
        {

            MemberPlanDao memberPlanDao = new MemberPlanDao();
            List<MemberPlan> memberPlanList = memberPlanDao.GetMemberPlanForId(int.Parse(lblmemberId.Text));

            PlanCodeDao planCode = new PlanCodeDao();
            List<PlanCode> planCodeList = planCode.ViewPlan();

            List<int> planIdList = new List<int>();

            for (int i = 0; i < memberPlanList.Count; i++)
            {
                for (int j = 0; j < planCodeList.Count; j++)
                {
                    if (memberPlanList[i].PlanCodeId == planCodeList[j].PlanCodeId)
                    {
                        planCodeList.RemoveAt(j);
                    }
                }
            }
            if(planCodeList.Count == 0)
            {
                PanelClaimMyPolicy.Visible = false;
                panelViewPolicy.Visible = false;
                panleNotification.Visible = false;
                panelNoNotification.Visible = false;
                paneNoPolicy.Visible = true;

            }
            else
            {

                gridViewPlan.DataSource = planCodeList;
                gridViewPlan.DataBind();


            }
          


        }
        catch (NoMemberPlanException ex)
        {

            //PanelClaimMyPolicy.Visible = false;
            //panelViewPolicy.Visible = false;
            //panleNotification.Visible = false;
            //panelNoNotification.Visible = false;
            //paneNoPolicy.Visible = true;
            PlanCodeDao planCode = new PlanCodeDao();
            List<PlanCode> planCodeList = planCode.ViewPlan();
            gridViewPlan.DataSource = planCodeList;
            gridViewPlan.DataBind();

        }
    
    }

    protected void JoinPolicy(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Join")
        {
            MemberPlanDao memberPlanDao = new MemberPlanDao();
            int rowindex = int.Parse(e.CommandArgument.ToString());
            int planCodeId = int.Parse(gridViewPlan.Rows[rowindex].Cells[0].Text);

            DropDownList ddl = (DropDownList)gridViewPlan.Rows[rowindex].FindControl("ddlCoverage");
            int coverageNumber = int.Parse(ddl.SelectedValue);

            DateTime startDat = DateTime.Now;
            DateTime endDat = DateTime.Parse("01/01/0001");

            float coverageAmount = 0;
            switch (coverageNumber)
            {
                case 1:
                    endDat = startDat.AddMonths(3);
                    coverageAmount = float.Parse(gridViewPlan.Rows[rowindex].Cells[3].Text);
                    break;
                case 2:
                    endDat = startDat.AddMonths(6);
                    coverageAmount = float.Parse(gridViewPlan.Rows[rowindex].Cells[4].Text);
                    break;
                case 3:
                    endDat = startDat.AddMonths(9);
                    coverageAmount = float.Parse(gridViewPlan.Rows[rowindex].Cells[5].Text);
                    break;
                case 4:
                    endDat = startDat.AddMonths(12);
                    coverageAmount = float.Parse(gridViewPlan.Rows[rowindex].Cells[6].Text);
                    break;
                case 5:
                    endDat = startDat.AddMonths(15);
                    coverageAmount = float.Parse(gridViewPlan.Rows[rowindex].Cells[7].Text);
                    break;
            }

            MemberPlan memberPlan = new MemberPlan(0, int.Parse(lblmemberId.Text), planCodeId, startDat, endDat, coverageAmount, coverageNumber);
            memberPlanDao.AddMemberPlan(memberPlan);



            displayPlan();
            Response.Write("<script>alert('" + "Joined Policy" + "')</script>");

        }
    }
    //######################################################,,,,JoinPolicy...################################################


    //######################################################,,,,ClaimPolicy...###############################################

    protected void gridPolicy_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //Claim claim = new Claim();
        int rowindex = int.Parse(e.CommandArgument.ToString());
        ////  int memberId = int.Parse(gridPolicy.Rows[rowindex].Cells[1].Text);
        ////claim.MemberId = int.Parse(Session["memberId"].ToString());
        //MemberPlanDao memberPlanDao = new MemberPlanDao();
        //claim.MemberPlanId1 = memberPlanDao.GetMemberPlanId(int.Parse(Session["memberId"].ToString()), int.Parse(gridPolicy.Rows[rowindex].Cells[0].Text));
        //claim.ClaimServiceDate = DateTime.Parse(gridPolicy.Rows[rowindex].Cells[5].Text);
        //claim.ClaimSubmissionDate = DateTime.Now;
        //claim.ClaimProcessingDate = DateTime.Now.AddDays(10);
        //claim.ClaimStatus = "Processing";
        //claim.ClaimAmount = 0;
        //ClaimDao claimDao = new ClaimDao();
        //claimDao.RequestClaim(claim);

        Server.Transfer("Claim.aspx?PolicyId="+ gridPolicy.Rows[rowindex].Cells[0].Text + "&ClaimNo=" + gridPolicy.Rows[rowindex].Cells[1].Text+ "&ClaimAmount=" + gridPolicy.Rows[rowindex].Cells[4].Text + "&ServiceDate=" + gridPolicy.Rows[rowindex].Cells[5].Text + "&policyName=" + gridPolicy.Rows[rowindex].Cells[2].Text);

       
    }
    protected void DisplayDataClaim()
    {
        try
        {
            

            MemberPlanDao member = new MemberPlanDao();
            List<MemberPlan> plan = member.GetMemberPlanForIdWhereNoClaim(int.Parse(Session["memberId"].ToString()));
            gridPolicy.DataSource = plan;
            gridPolicy.DataBind();


        }
        catch (NoMemberPlanException ex)
        {

            PanelClaimMyPolicy.Visible = false;
            panelViewPolicy.Visible = false;
            panleNotification.Visible = false;
            panelNoNotification.Visible = false;
            paneNoPolicy.Visible = true;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        PanelClaimMyPolicy.Visible = true;
        panelViewPolicy.Visible = false;
        panleNotification.Visible = false;
        panelViewPolicy.Visible = false;
        paneNoPolicy.Visible = false;
        DisplayDataClaim();
    }


    //######################################################,,,,JoinPolicy...################################################

    public void DisplayReSubmitClaims()
    {
        try
        {
            MemberDao memberDao = new MemberDao();
            List<Claim> resubmitList = memberDao.ClaimStatusRejected(int.Parse(Session["memberId"].ToString()));
            gridReSubmitClaims.DataSource = resubmitList;
            gridReSubmitClaims.DataBind();
        }
        catch(Exception ea)
        {
            lblReSubmit.Visible = true;
        }

    }



    protected void gridReSubmitClaims_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int rowindex = int.Parse(e.CommandArgument.ToString());
        Server.Transfer("ClaimResubmit.aspx?ClaimId=" + gridReSubmitClaims.Rows[rowindex].Cells[0].Text+ "&policyName="+ gridReSubmitClaims.Rows[rowindex].Cells[1].Text);
    }
}