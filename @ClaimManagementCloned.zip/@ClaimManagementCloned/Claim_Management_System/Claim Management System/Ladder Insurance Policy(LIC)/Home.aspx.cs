﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            StringBuilder html = new StringBuilder();



            PlanCodeDao planDao = new PlanCodeDao();
            List<PlanCode> planList = new List<PlanCode>();

            planList = planDao.ViewPlan();
            foreach (PlanCode plan in planList)
            {
                //html.Append(" <asp:HyperLink  runat=\"server\"  NavigateUrl=\"~/ Login.aspx\">");
                html.Append("<div class=\"plan_content\" onclick=\"plan()\">");
                html.Append("<h1>" + plan.PlanName + "</h1>");
                html.Append("<p>" + plan.PlanDescription + "</p>");

                html.Append("<h3>Coverage:" + plan.Coverage1 + "</h3>");
                html.Append("<h3>Coverage:" + plan.Coverage2 + "</h3>");
                html.Append("<h3>Coverage:" + plan.Coverage3 + "</h3>");
                html.Append("<h3>Coverage:" + plan.Coverage4 + "</h3>");
                html.Append("<h3>Coverage:" + plan.Coverage5 + "</h3>");
                html.Append("</div>");
                // html.Append("</asp:HyperLink>");
            }

            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }
        catch(Exception ex)
        {
            Response.Write("<script>alert('" + "no policy to display on homepage" + "')</script>");
        }
    }
}