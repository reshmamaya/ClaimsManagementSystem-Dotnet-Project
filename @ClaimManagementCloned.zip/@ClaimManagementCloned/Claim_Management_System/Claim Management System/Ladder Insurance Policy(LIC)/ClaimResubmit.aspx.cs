﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            if (Session["type"] != null)
            {

                if (Session["type"].ToString() != "User")
                {
                    Response.Redirect("Login.aspx");
                }

            }

            lblClaimPolicyName.Text = Request.QueryString["policyName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + "Wrong navigation of page!" + "');window.location.href='CustomerHomePage.aspx';</script>");
        }

    }


    protected void btnRequestClaim_Click1(object sender, EventArgs e)
    {
        try
        {
            ClaimDao claimDao = new ClaimDao();
            int claimid = int.Parse(Request.QueryString["ClaimId"].ToString());
            
            claimDao.ResubmitClaim(claimid);
            Response.Write("<script>alert('" + "Claiming initiated again" + "');window.location.href='CustomerHomePage.aspx';</script>");
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + "something goes wrong try again !" + "');window.location.href='CustomerHomePage.aspx';</script>");
        }
       
    }

    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        Response.Redirect("CustomerHomePage.aspx");
    }
}