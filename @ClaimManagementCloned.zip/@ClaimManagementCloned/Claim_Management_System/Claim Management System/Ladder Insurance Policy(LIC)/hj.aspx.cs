﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            try
            {
                DisplayDataClaim();
            }
            catch(NoMemberPlanException ex)
            {
                Response.Write("<script>alert('No Member Plan')</script>");
            }
        }
    }

    protected void gridPolicy_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        Claim claim = new Claim();
        int rowindex = int.Parse(e.CommandArgument.ToString());
        int memberId = int.Parse(gridPolicy.Rows[rowindex].Cells[1].Text);
        claim.MemberId = int.Parse(Session["memberId"].ToString());
        claim.ClaimServiceDate =DateTime.Parse(gridPolicy.Rows[rowindex].Cells[5].Text);
        claim.ClaimSubmissionDate = DateTime.Now;
        claim.ClaimProcessingDate = DateTime.Now.AddDays(10);
        claim.ClaimStatus = "Processing";
        claim.ClaimAmount = 0;
        ClaimDao claimDao = new ClaimDao();
        claimDao.RequestClaim(claim); 
    }
    protected void DisplayDataClaim()
    {
        try
        {
            MemberPlanDao member = new MemberPlanDao();
            List<MemberPlan> plan = member.GetMemberPlanForId(int.Parse(Session["memberId"].ToString()));
            List<string> gridContent = new List<string>();
            PlanCodeDao planDao = new PlanCodeDao();
            List<PlanCode> planList = new List<PlanCode>();
            planList = planDao.ViewPlan();
            List<PlanCode> newPlanList = new List<PlanCode>();
            PlanCode plan1 = new PlanCode();
            for (int i = 0; i < plan.Count; i++)
            {
                for (int j = 0; j < planList.Count; j++)
                {
                    if (plan[i].PlanCodeId == planList[j].PlanCodeId)
                    {
                        newPlanList.Add(planList[j]);
                    }
                }
            }
            for (int i = 0; i < plan.Count; i++)
            {
                gridContent.Add(plan[i].PlanCodeId.ToString());
                gridContent.Add(newPlanList[i].PlanName.ToString());
                gridContent.Add(newPlanList[i].PlanDescription);
                gridContent.Add(plan[i].CoverageAmount.ToString());
                gridContent.Add(plan[i].StartDate.ToString("dd/MM/yyyy"));
                gridContent.Add(plan[i].EndDate.ToString("dd/MM/yyyy"));
            }
            gridPolicy.DataSource = gridContent;
            gridPolicy.DataBind();
        }
        catch (NoMemberException ex)
        {

            Response.Write("<script>alert('No member plan avilable')</script>");
        }
        
    }
}