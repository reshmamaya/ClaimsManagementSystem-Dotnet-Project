﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage2 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            
            if (Session["username"].ToString() != null)
            {
                Label1.Text = Session["username"].ToString();

            }
            else
            {
                Response.Write("<script>alert('Please register');window.location.href='Login.aspx'</script>");
            }
        }
        catch (Exception)
        {

            Response.Write("<script>alert('Please Login');window.location.href='Login.aspx'</script>");
        }
       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //Session["username"] ="null" ;
        Session.Abandon();
        Response.Redirect("Home.aspx");
    }
}
