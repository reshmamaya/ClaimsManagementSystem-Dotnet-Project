﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["type"] != null)
            {
                if (Session["type"].ToString() != "Admin")
                {
                    Response.Redirect("AdminLogin.aspx");
                }

            }
            if (Session["Message"].ToString() == "approve")
            {
                regApprove.Visible = true;
                int claimId = int.Parse(Request.QueryString["ClaimId"].ToString());
                ClaimDao claimDao = new ClaimDao();
                Claim claim = claimDao.ViewClaimById(claimId);
                lblMemberName.Text = claim.FirstName;
                lblPlanName.Text = claim.PlanName;
                lblClaimServiceDate.Text = claim.ClaimServiceDate.ToString("dd/MM/yyyy");
                lblClaimSubmissionDate.Text = claim.ClaimSubmissionDate.ToString("dd/MM/yyyy");
                lblClaimAmount.Text = claim.ClaimAmount.ToString();
                lblMessage.Text = "Amount To Approve";
                btnReject.Visible = false;

            }
            else
            {

                int claimId = int.Parse(Request.QueryString["ClaimId"].ToString());
                ClaimDao claimDao = new ClaimDao();
                Claim claim = claimDao.ViewClaimById(claimId);
                lblMemberName.Text = claim.FirstName;
                lblPlanName.Text = claim.PlanName;
                lblClaimServiceDate.Text = claim.ClaimServiceDate.ToString("dd/MM/yyyy");
                lblClaimSubmissionDate.Text = claim.ClaimSubmissionDate.ToString("dd/MM/yyyy");
                lblClaimAmount.Text = claim.ClaimAmount.ToString();
                lblMessage.Text = "Reason For Rejection";
                btnApprove.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + "Wrong navigation of page!" + "');window.location.href='AdminHomePage.aspx';</script>");
        }

    }

    protected void btnApprove_Click(object sender, EventArgs e)
    {
        try
        {
            int claimId = int.Parse(Request.QueryString["ClaimId"].ToString());
            ClaimDao claimDao = new ClaimDao();
            claimDao.ApproveClaim(claimId, "Approved", float.Parse(txtAmounApprove.Text));
            Response.Write("<script>alert('" + "Claim Approved" + "');window.location.href='AdminHomePage.aspx';</script>");
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + "something goes wrong try again !" + "');window.location.href='AdminHomePage.aspx';</script>");
        }
    }

    protected void btnReject_Click(object sender, EventArgs e)
    {
        try
        {
            int claimId = int.Parse(Request.QueryString["ClaimId"].ToString());
            ClaimDao claimDao = new ClaimDao();
            string reason = "Rejected - " + txtAmounApprove.Text.ToString();
            claimDao.ApproveClaim(claimId, reason, 0);
            Response.Write("<script>alert('" + "Claim Rejected" + "');window.location.href='AdminHomePage.aspx';</script>");
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + "something goes wrong try again !" + "');window.location.href='AdminHomePage.aspx';</script>");
        }
    }
}