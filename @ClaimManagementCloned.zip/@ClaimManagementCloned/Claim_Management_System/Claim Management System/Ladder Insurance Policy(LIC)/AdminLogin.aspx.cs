﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button2.Focus();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string username = txtUserName.Text;
        string password = txtPassword.Text;
        AdminDao adminDao = new AdminDao();
        int status = adminDao.LoginAdmin(username, password);
        //int status =2;
        if (username == "SuperUser" && password == "SuperUser")
        {
            Session["username"] = username;
            Session["type"] = "SuperUser";

            Response.Redirect("SuperUserHome.aspx");
        }
        else if (status == 1)
        {
            Session["username"] = username;
            Session["type"] = "Admin";
            Response.Redirect("AdminHomePage.aspx");


        }
        else if (status == 2)
        {

            alert_box.Attributes["class"] = "alert";

            lblalert.Text = "You login is not accepted by admin";

            txtPassword.CssClass = "textbox_red";
            txtUserName.CssClass = "textbox_red";
            Response.Redirect("RejectionPage.aspx");

        }
        else if (status == 3)
        {
            alert_box.Attributes["class"] = "alert";

            lblalert.Text = "You are not active ! please wait for sometime";
            txtPassword.CssClass = "textbox_red";
            txtUserName.CssClass = "textbox_red";
        }
        else if (status == 0)
        {
            alert_box.Attributes["class"] = "alert";

            lblalert.Text = "Please check the credentials. If not registered, please register";
            txtPassword.CssClass = "textbox_red";
            txtUserName.CssClass = "textbox_red";
        }
    }
}