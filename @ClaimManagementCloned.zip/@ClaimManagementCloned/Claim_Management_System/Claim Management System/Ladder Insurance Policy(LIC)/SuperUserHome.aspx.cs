﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClaimsBusinessLayer;
using ClaimsDataLayer;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"] != null)
        {
            if (Session["type"].ToString() != "SuperUser")
            {
                Response.Redirect("AdminLogin.aspx");
            }
        }
        if (!IsPostBack)
        {
      
            PanelNotification.Visible = false;
            PanelGridView.Visible = false;
            DisplayData();
        }


        
        
        
    }
    protected void ApproveAdmin(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ApproveAdmin")
        {
            AdminDao admin = new AdminDao();
            int rowindex = int.Parse(e.CommandArgument.ToString());
            int adminId = int.Parse(gridSuperUser.Rows[rowindex].Cells[0].Text);
            admin.ApproveAdmin(adminId, "Yes");
        }
        else if (e.CommandName == "RejectAdmin")
        {
            AdminDao admin = new AdminDao();
            int rowindex = int.Parse(e.CommandArgument.ToString());
            int adminId = int.Parse(gridSuperUser.Rows[rowindex].Cells[0].Text);
            admin.ApproveAdmin(adminId,"No");
        }
        DisplayData();
    }


    protected void DisplayData()
    {
        try
        {
            PanelNotification.Visible = false;
            PanelGridView.Visible = true;
            AdminDao Admin = new AdminDao();
            List<Admin> adminList = Admin.GetAdminListForSuperUser();
            gridSuperUser.DataSource = adminList;
            gridSuperUser.DataBind();

        }
        catch (Exception ec)
        {
            // Response.Write("<script>alert('No admin is present');window.location.href='AdminLogin.aspx'</script>");
            PanelNotification.Visible = true;
            PanelGridView.Visible = false;
        }
    }
}